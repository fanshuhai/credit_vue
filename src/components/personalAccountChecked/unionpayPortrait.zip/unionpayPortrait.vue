<template>
    <div class="bankCardcheckPage">
        <div class="createSearch">
            <el-form :model="form"  ref="form" label-width="80px" :label-position="labelPosition">
                <div style="height: 3em;border-bottom: 1px solid #ccc;line-height: 3em;"><span style="margin-left: 30px">新建查询</span></div>
                <div style="margin-top:40px">
                    <el-row :gutter="15">
                        <el-col :span="6">
                            <el-form-item label="姓名:" style="margin-left: 30px" >
                                <el-input v-model="form.name" placeholder=""></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="6">
                            <el-form-item label="银行卡号:" style="margin-left: 30px">
                                <el-input v-model="form.bankCard" placeholder=""></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="6">
                                    
                        </el-col>
                    </el-row>
                </div>
            </el-form>
        </div>
        <div class="searchResult">
            <div style="height: 3em;line-height: 3em;">
                <span style="margin-left: 30px">查询结果样例</span>
            </div>
            <template>
                <div>
                    <el-table :data="unionpayTableData" :header-cell-style="headStyle" :span-method="SpanMethod" border style="width: 90%;margin-left: 2%;text-align: center;margin-top: 2%">
                      <el-table-column label="查询类别" colspan="2"  prop="searchCategory"></el-table-column>
                      <el-table-column label="查询项名称"  prop="searchProjectName"></el-table-column>
                      <el-table-column label="时间范围"  prop="timeScope"></el-table-column>
                      <el-table-column label="查询结果"  prop="searchResult"></el-table-column>
                      <el-table-column label="备注"  prop="remarks"></el-table-column>
                    </el-table>
                </div>
            </template>
        </div>
    </div>
    
</template>

<script>
    export default{
        data(){
            return{
                labelPosition:'left',
                form: {
                   name:'',
                   bankCard:'',
                },
                unionpayTableData:[
                    {
                        searchCategory: '持卡人概览',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    },
                    {
                        searchCategory: '基础交易统计',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    },
                    {
                        searchCategory: '金融交易统计',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    },
                    {
                        searchCategory: '风险交易统计',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    },
                    {
                        searchCategory: '消费行业统计',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    },
                    {
                        searchCategory: '资产状况',
                        searchProjectName: '',
                        timeScope: '',
                        searchResult: '',
                        remarks: ''
                    }
                ]
            }
        },
        methods:{
            onSubmit(){
                console.log("提交")
            },
            headStyle({row,column,rowIndex,columnIndex}){
               
                return 'text-align:center'
            },
            SpanMethod({row,column,rowIndex,columnIndex}){
                // if(rowIndex === 0){
                //     if(columnIndex === 0){
                //         return [1,2]
                //     }
                // }
                // if(rowIndex % 2 === 0){
                //     if(columnIndex === 0){
                //         return [1,1];
                //     }else if(columnIndex === 1){
                //         return [0,0]
                //     }
                //     else if(columnIndex === 2){
                //         return [0,0]
                //     }else if(columnIndex === 3){
                //         return [0,0]
                //     }else if(columnIndex === 4){
                //         return [0,0]
                //     }
                // }
            }
        }
       
    }
</script>

<style>
  /*  .bankCardcheckPage{
        background: #fff;
        width: 100%
    }
    .createSearch{
        border: 1px solid #ccc;
        width: 90%;
        margin-left: 5%;
        margin-top: 3%;
        height: 20%;
    }
    .searchResult{
        border: 1px solid #ccc;
        width: 90%;
        margin-left: 5%;
        margin-top: 3%;
        height: 50%;
    }*/
</style>