<template>
    <div id="login-wrap" class="login-wrap">
        <canvas id="canvas" class="canvas"></canvas>
        <div class="ba-content">
            <div class="ms-title">
                <div class="ms-cont">
                  <div class="ms-cont1">
                      
                  </div>
                  <div class="ms-cont2">
                    大数据智能风控平台
                  </div> 
                </div>
            </div>
            <div class="ms-login">
                <div class="ms-loginContent">
                    <div class="loginContent1">用户登录</div>
                    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="0px" class="demo-ruleForm">
                        <el-form-item prop="username">
                            <el-input class="login-msg" v-model="ruleForm.username" placeholder="账号">
                            	<!--<el-button slot='prepend' icon="el-icon-people"></el-button>-->
                            </el-input>
                        </el-form-item>
                        <el-form-item prop="password">
                            <el-input  class="login-msg" type="password" placeholder="密码" v-model="ruleForm.password" @keyup.enter.native="submitForm('ruleForm')">
                            	<!--<el-button slot='prepend' icon='el-icon-lx-people'></el-button>-->
                            </el-input>
                        </el-form-item>
                    </el-form>
                   <!--  <el-input  v-model="ruleForm.username" placeholder="账号"></el-input>
                    <el-input  type="password" placeholder="密码" v-model="ruleForm.password" @keyup.enter.native="submitForm('ruleForm')"></el-input> -->
                    <div class="agreement">
                        <el-checkbox v-model="agreementAmount">我已阅读并同意遵守</el-checkbox>
                        <el-button type="text" @click="dialogAgreement=true">《用户协议》</el-button>
                    </div>
                    <div class="login-btn">
                        <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- 协议对话框 -->
        <el-dialog
        class="agrermentDialog"
        title="用户协议"
        :modal='true'
        width='40%'
        :append-to-body='true'
        :visible.sync="dialogAgreement">
            <div class="agrermentContent">
                <div class="titleStyle">用户协议</div> 
                <div> 欢迎使用摩尔征信，在您使用本公司提供的各项服务之前，请务必仔细阅读并透彻理解本协议。</div>
                <div> 
                本协议是您和【深圳氢诺科技有限公司】（以下简称 “本公司” ）为明确服务内容及双方权利义务等而签订。
                </div>
                <div> 
                本网站有权根据需要不时地修改和补充本协议或各类规则，经修订和补充的各类规则，是本协议的组成部分。如本条款及规则有任何变更，一切变更以本网站最新公布的文本为准。本网站将随时公告本协议及条款的变更情况 , 经修订的协议、条款一经公布，立即生效。如果您在任何时候对任何内容存在疑虑或异议，请您立即停止使用本网站并停止接受本网站的服务；若您继续使用本网站的服务，即视为您决定接受服务规则。
                </div>
                <div> 
                如您不同意本协议及其更新内容，您可以主动取消本公司提供的服务；您一旦使用本公司的服务，即视为您已了解并完全同意本协议的各项内容。由于数据行业的特殊性，本公司具有保留修改或中断部分或全部服务的权利。
                </div>

                <div>
                一、定义及解释
                </div> 
                <div>
                1.1“您” ：指为使用或可能使用服务而在本网站使用登记的依法使用有效存续的法人或自然人，能够独立承担民事责任。
                </div>
                <div>
                1.2 本协议：指您与本公司签订的《用户协议》。
                </div>
                <div>
                1.3 本网站：指本公司拥有的摩尔征信网站，网址： http://724.moerlong.com ，本网站的权利义务均归属于本公司。
                </div>
                <div>
                1.4 服务：指本协议第三款规定的本网站现在和将来实际向您提供的电商、运营商、央行征信、身份、社保、公积金、信用卡等多维数据查询以及决策分析、精准营销、辅助催收和风险评估等数据服务。
                </div>
                <div>
                1.5 处理：指对任何信息的保存、整理、分析、比对、演算、归纳及（或）加工等各项操作。
                </div>

                <div>
                二、服务规则
                </div> 
                <div>
                2.1 您在本网站使用成功以后即享有相应的账户及密码，您需设置专门的操作人员妥善保存该账号、密码及信息指令的发出，不得擅自转借或授权第三方使用。本网站通过您的账户接受来自您的指令，无论您通过何种方式向本公司发出指令，都不可撤回或撤销，且视为您本人的指令。您账户项下、发出的指令及其造成的后果发生任何侵权、违约等责任的，由您自行负责并承担相应的责任。
                </div>
                <div>
                2.2 您一经使用即有权根据本协议及本网站的相应规则，参与本网站的相关活动并享受本网站提供的数据服务，本网站根据您的选择为您提供相应的数据记录服务。
                </div>
                <div>
                2.3 本网站有权在您未提供真实、准确、有效的信息时，暂停为您提供相关服务。您有义务维护您的信息，当您信息有变化的，应当积极向本网站及时更新。（注：该等信息包括但不限于您的真实名称、证件号码、最新证照、联系地址、联系电话、联系人等）
                </div>
                <div>
                2.4 本网站有权对您的使用资料进行审查，对存在任何问题或怀疑的使用资料，本网站有权发出通知询问您并要求您做出解释、改正。
                </div>
                <div>
                2.5 若本网站后台审核未通过，本网站有权拒绝您的使用申请或禁止为您提供某些服务。
                </div>
                <div>
                2.6 您应当自行依法承担因使用本网站服务而产生的税费。
                </div>
                <div>
                2.7 未经本网站书面同意，您不得将本网站的任何资料、信息另做它用；您亦不得将上述材料用作任何非法用途。
                </div>
                <div>
                2.8 若您有下列行为或可能为下列行为的，本网站有权在不通知您的前提下，删除或采取其他限制性措施处理如下信息：包括但不限于违反本协议约定的义务；以规避费用为目的；以信用滥用为目的；以非法获取他人信息牟利为目的；以合法方式掩盖非法目的等；存在欺诈等恶意或虚假内容；与网上交易无关或非以交易为目的；存在恶意竞价或其他试图扰乱正常交易秩序因素；违反公共利益或可能严重损害本网站、第三人合法权益。  
                </div>
                <div>
                2.9 您在使用本网站服务之前，如涉及第三人的，应当取得该第三人的合法有效授权，并且该等授权可转委托，否则由此产生的责任，由您自行承担。
                </div>
                <div>
                2.10 本网站依据本协议及相关规则，在您使用本网站的服务后或本网站判断您的账户存在风险的，本网站可以划扣、冻结、先行赔付等处置您预存在本网站账户内的资金。如果被封号、冻结的账户中有资金，可在账户中扣除您的不正当收入及相应的赔偿。
                </div>

                <div>
                三、服务内容
                </div> 
                <div>
                3.1 本网站为您提供专业评估报告、基础征信数据、客户分析服务。
                </div>
                <div>
                3.2 本网站为您提供的服务内容具体参见本网站的通知、公告、说明等。
                </div>
                <div>
                3.3 本网站为了向您提供更好的服务，可能会在本网站上指向第三方网站的链接。第三方网站的链接不受本网站控制，本网站不对其所展示的内容、提供的服务承担任何责任，您应自行选择是否接受第三方网站的链接或其提供的服务。
                </div>
                <div>
                3.4 本网站为了向您提供更好的服务，需要您提供或主动输入被查询主体的基本信息、手机号码、公积金账户、社保账户、电商账户、央行征信账户等网站用户名及密码等，您应当在取得被查询主体的同意后方可向本网站提供。
                </div>
                <div>
                3.5 在您使用本网站服务时，本网站有权依照收费细则向您收取服务费用。本网站拥有制订及调整服务费之权利，具体服务费用以您使用本网站服务时本网站公告或您与本公司达成的其他书面协议为准。一旦您继续使用本网站服务的，即视为您接受本网站的相关费用标准。
                </div>
                <div>
                3.6 本网站为您提供充值服务，您可在本网站的账户内预存一定的费用，本网站按您使用的服务进行计费，当账户内的余额不足时，您应补足，否则本网站有权拒绝为您提供服务。
                </div>

                <div>
                四、服务限制及终止
                </div> 
                <div>
                4.1 若您利用本网站提供的服务，违反相关法律、行政法规、地方性法规、部门规章、违反公序良俗、诚实信用、违背社会公共利益或侵犯第三人合法权益的，本网站有权终止服务并要求您立即停止使用本网站服务，由此给本网站带来损失的，本网站有权追偿。
                </div>
                <div>
                4.2 为了保证第三人的合法权益，本网站有权基于您查询的数据类型随时要求您提供第三人的合法有效授权，否则本网站有权拒绝为您提供任何服务，若您未能提供该等授权或该等授权有瑕疵的，本网站有权终止向您提供服务，由此给本网站造成不良影响或损失的，本网站有权追偿。
                </div>
                <div>
                4.3 您同意如您违反以下保证或发生相关情形，本网站将有权限制或终止向您提供本协议项下的部分或全部服务。</div>
                <div>4.3.1 您应是依法使用、有效存续，并合法开展经营范围内业务的企业法人。</div>
                <div>4.3.2 您确认在您使用本网站前，操作人员已获得您的授权，您已认真、仔细阅读并充分理解本协议的所有条款内容。您的决策机构也已认可和同意本次使用行为，并在您同意本协议所有条款并使用后，您将有权依据本协议的条款享受本网站的服务，同时您有义务接受本协议条款的约束。如有违反本协议而导致任何法律后果的发生，您将以自己的名义独立承担所有的法律责任。</div>
                <div>4.3.3 任何时候您都不得将本网站的服务用于任何非法目的，比如侵害他人合法权益，或者以非法方式使用本网站的服务。</div>
                <div>4.3.4 您保证，在本网站为您提供服务期间，您向本网站提供的所有资料和信息都是真实、完整、准确的并及时更新。本网站有权在发现您的身份存疑或涉嫌冒用他人身份信息或伪造资料和（或）信息时，要求您配合补全或更新相关身份信息及资料。</div>
                <div>4.3.5 您承诺不得授权他人使用本网站的服务。不得将用于登录的账户、密码、使用信息等披露或提供给其他人代替您操作、使用本网站的服务。若您违反该等义务而给您造成损失或导致不良行为记录的后果将由您自行承担。</div>
                <div>4.3.6 如果本网站认为您没有遵守本协议的约定，或者本网站认为继续为您提供服务将会导致本网站或第三方的合理利益受到损失。</div>
                
                <div>
                4.4 您理解并同意，存在如下情形时，本网站有权对您名下账户或交易进行限制或追回，且有权限制您所使用的产品或服务的部分或全部功能：</div>
                <div>1) 根据本协议的约定；</div>
                <div>2) 根据法律法规规定及有权机关的要求；</div>
                <div>3) 您使用服务的行为涉嫌违反国家法律法规及行政规定的；</div>
                <div>4) 本网站基于单方面合理判断认为账户信息、操作等存在异常时；</div>
                <div>5) 您在参加市场活动时有批量使用账户、提供虚假信息或材料及其他舞弊等违反活动规则、违反诚实信用原则的；</div>
                <div>6) 本网站依据自行合理判断认为可能产生风险的；</div>
                <div>7) 计费错误或系统故障等导致您可能存在不当得利的；</div>
                
                <div>
                4.5 如您申请解除上述冻结或限制，您应按本网站要求如实提供相关资料及您的身份证明以及本公司要求的其他信息或文件，以便本网站进行核实，且本网站有权依照自行判断来决定是否同意您的申请。
                </div>

                <div>
                五、 服务中断或故障
                </div> 
                <div>
                5.1 您充分理解并同意本网站无须就下述情况所导致服务无法正常提供时给您造成的各种影响或损失承担责任：</div>
                <div>1) 系统维护、网站升级期间；</div>
                <div>2) 电信故障；</div>
                <div>3) 发生台风、地震、海啸、洪水、停电、战争、恐怖袭击、黑客攻击等事件造成本网站系统故障、服务中断或延迟的。</div>
                

                <div>
                六、 协议的变更和终止
                </div>
                <div>
                6.1 鉴于网络服务的特殊性，本网站变更本协议及其附件的若干条款时，将提前通过本网站公告有关变更事项。如您在本网站发布上述协议变更的有关公告后继续使用本网站服务的，视为您已接受协议的有关变更，并受其约束。本协议中的相关条款根据该变更而自动做相应修改，双方无须另行签订协议。
                </div>

                <div>
                七、 知识产权
                </div>
                <div>
                7.1 本网站包括享有知识产权的材料、商标和其他拥有所有权的信息，包括文本、图形、软件、照片、音乐、影像和声音等。本网站拥有对这些内容及这些内容的原作进行选择、协调、安排和增加的版权。您不能进行修改、出版、传播、参加转让或售卖、创作派生作品、或以任何方式部分或全部利用这些内容的任何一种。
                </div>
                <div>
                7.2 您确认您不对下载、保存下来的材料、使用的软件、技术享有任何所有权。   
                </div>
                <div>
                7.3 您只可因自行使用而下载享有知识产权的材料。任何未经本网站特别允许的复制、再分发、再传播、对下载材料的出版或商业性的利用都是不允许的。任何经允许的复制、再分发、再传播、对下载材料的出版中不得对原创人意图、商标图例或版权说明做任何改动。  
                </div>
                <div>
                7.4 您不得在网站上传、张贴任何受版权、商标或其他受保护却未经权利人特别同意的材料；由此而侵犯他人合法权利的，由您承担所有责任。    
                </div>
                <div>
                7.5 如您在本网站的任何公共区域提交材料，则您自动允许或授权该材料的所有者已特别授权本网站享有免费使用、永久的、不能变更的、非专利的权利，并拥有在全世界范围内使用、复制、修改、改编、出版、翻译、分发这些材料（部分或全部地）和 / 或在这些材料中包含的任何版权期限内以任何形式、媒体或者现在已知或以后将发展的技术合并这些材料的特许。您因此允许本网站享有编辑、复制、出版和分发任何您放置在网站上可自由获得的材料的权利。    
                </div>

                <div>
                八、信息的采集
                </div>
                <div>
                8.1 当您使用本网站时，您需根据本网站的使用要求向本网站提供相应的信息，以便向您提供服务。   
                </div>
                <div>
                8.2 当您使用本网站的服务时，您需向本网站提供该等服务对应所需的材料。例如您需第三人的社保信息时，您需向本网站提供或自行输入第三人的社保账号及密码。    
                </div>
                <div>8.3 本网站收集信息的范围主要包括：</div>
                <div>8.3.1 本网站为了向您提供服务，根据法律法规要求，需要识别您及第三人的身份。本网站需要您提供您及第三人的信息，包括但不限于名称、身份证明、地址、电话号码和电子邮箱等信息。</div>
                <div>8.3.2 如您使用的本网站服务需与您的银行账户或其他支付工具的账户关联方能实现时，您需要向本网站提供您的银行账户信息或其他支付工具的账户信息。</div>
                <div>8.3.3 为了使用本网站或获得更好的服务，您提供的使用申请信息、第三人的社保公积金、央行征信、学历学籍、网贷平台、电商结构化等账号及密码。</div>
                <div>8.3.4 为便于查询您的交易状态或历史记录，也为了遵守法律法规的规定，本网站会保存您使用本网站服务产生的交易信息，并严格按照法律法规的规定对这些信息进行妥善保管。</div>
                <div>8.3.5 为了确认和评估您及第三方的资信状况，本网站通过官方认证及第三方平台获取的信息仅用于评估信用状况所用。</div>
                <div>8.3.6 为了充分保护您的账户安全，当您访问本网站及其相关网站时，或使用本网站提供的服务时，本网站可能会记录您操作的相关信息，包括但不限于您的计算机 IP 地址、设备标识符、硬件型号、操作系统版本、您的位置以及与本网站服务相关的日志信息。</div>
                <div>8.3.7 除上述信息外，本网站还可能为了提供服务及改进服务质量的合理需要而收集的其他用户信息。</div>    
                

                <div>
                九、信息的使用
                </div>
                <div>9.1 因收集信息是出于遵守国家法律法规的规定以及向您提供服务及提升服务质量的目的，为了实现这一目的，本网站会把收集的信息用于下列用途：</div>
                <div>9.1.1   向您提供本网站的各项服务及客户服务，并维护、改进这些服务。</div>
                <div>9.1.2   比较信息的准确性，并与第三方进行验证。例如，将您留存、传递至本网站的您及第三人身份信息与身份验证的服务机构进行验证。</div>
                <div>9.1.3   为使您知晓自己使用本网站服务的情况或了解本网站的服务，向您发送服务状态的通知、营销活动及其他商业性电子信息。</div>
                <div>9.1.4   对第三人的身份数据、交易信息等进行综合统计、分析或加工、整理，并出于销售、奖励或为了让您拥有更完美体验的需要而使用、共享或披露。</div>
                <div>9.1.5   本网站为维护本网站权益或国家、集体、第三人的权益而预防或禁止的非法活动。</div>
                <div> 9.1.6   经您或第三人许可的其他用途。 </div>   
                

                <div>
                十、授权条款
                </div>
                <div>
                10.1 对于您提供的资料、数据信息，及本协议所涉信息，您授予或转授予本网站独家的、全国范围内的、永久的、免费的许可使用权利 ，并有权对该权利进行再授权。   
                </div>
                <div>
                10.2 您理解并同意，您使用使用本网站时，即授权本网站根据您所提供的各项信息及本网站独立获得的信息进行数据收集并形成数据记录。
                </div>
                <div>
                10.3 您在此不可撤销的同意并确认您提供的个人或第三人信息，例如名称、身份证明、地址、电话号码和电子邮箱等信息及相关附加信息，您授权或转授权我司有权获取、使用、暂时保存该等信息。   
                </div>
                <div>
                10.4 您理解并同意，授权 / 转授权我公司获得并使用您 / 第三人提供的信用卡账单邮箱数据。
                </div>
                <div>
                10.5 您理解并同意，如您向本网站提交、绑定或授权 / 转授权您 / 第三人的银行卡信息／账户，本网站将可能 :</div>
                <div>1 ） 查询并核对您 / 第三人的账户信息。</div>
                <div>2 ） 查询并读取您 / 第三人的银行卡账户中的交易信息。</div>
                <div>
                10.6 您理解并同意，如您向本网站转授权第三方的社保公积金信息、央行征信记录、学历学籍信息、网贷平台信息、电商结构化数据（包括但不限于淘宝、天猫等交易记录）等，本网站将可能读取您所转授权的账号中的相关信息。   
                </div>
                <div>
                10.7 您理解并同意，本网站将可能依据《征信业管理条例》及相关法律法规，向第三方支付 / 征信 / 金融机构等合法了解、获取、核实信用信息。所获取的个人信用信息仅在限定业务中使用，且不向其他机构、个人提供或披露。   
                </div>
                <div>
                10.8 您理解并同意，在使用过程中选择的银行或第三方合作机构基于更好的为您提供服务有权获得您的相关信息。
                </div>
                <div>
                10.9 您理解并同意，本网站可以储存您授权 / 转授权的原始信息；在本网站为您提供服务的期间，本网站随时可以重新采集和更新数据，对于经过加工和脱敏处理的数据，本网站可以永久保存在服务器上。 
                </div>
                <div>
                10.10 您理解并同意，您不可撤销的授权 / 转授权本网站向合法经营的第三方查询或核实您的相关信息；您同意本网站、本网站关联公司 / 合作公司有权对您的相关交易信息进行收集并在与业务相关的其他第三方之间共享；同时同意本网站将查询获取的信息进行保存、整理、加工。（但法律、法规、监管政策禁止查询的除外）。
                </div>
                <div>
                10.11 您理解并同意当本协议有关的信息或授权等涉及第三方时，您已获得第三方的授权并有权将该等权利转授权本网站，否则您不得使用本网站提供的服务，若因此给本网站带来损失的，本网站有权向您追偿。   
                </div>

                <div>
                十一、 保密及隐私
                </div>
                <div>
                11.1 本网站及您保证在磋商、签订、履行本协议中所获悉的属于对方的且无法自公开渠道获得的文件及资料（包括但不限于商业秘密、公司计划、运营活动、财务信息、技术信息、经营信息及其他商业秘密）予以保密。   
                </div>
                <div>
                11.2 对于以下信息，双方均免除相应的保密责任：由公众通过合法途径获知的信息；有明确证据证明从第三方获知的；
                </div>
                <div>
                11.3 本条规定的保密义务具有永久法律效力，不因本协议的变更、解除或终止而终止。
                </div>
                <div>
                11.4 任何一方违反本保密条款约定的，应当赔偿由此给对方造成的一切损失。
                </div>
                <div>
                11.5 本网站重视对个人隐私的保护。因收集个人的信息是出于遵守国家法律法规的规定以及向您提供服务及提升服务质量的目的，本网站对个人的信用信息承担保密义务。
                </div>
                <div>
                11.6 在服务终止后，本网站不会继续保留您使用本网站的服务期间形成的所有信息和数据，但该等使用仅为后续数据分析所用。
                </div>
                <div>
                11.7 本网站有权在下列情况下将您所提供的信息向第三人披露：</div>
                <div>11.7.1 获得信息主体的同意 / 授权 / 转授权；</div>
                <div>11.7.2 为了向您提供或推荐服务、产品、或为了向您提供更完善的服务，我们会在必要时向合作机构共享您的相关信息；</div>
                <div>11.7.3 在某些情况下只有共享您的信息才能向您提供您需要的服务或者产品，或处理您与他人的交易或者纠纷、争议；</div>
                <div>11.7.4 为了判断您的账户是否安全；</div>
                <div>11.7.5 我们与第三方进行联合推广活动，我们可能与其共享活动过程中产生的、为完成活动所必要的个人信息；</div>
                <div> 11.7.6 为维护本网站及关联公司、第三方的合法权益；</div>
                <div> 11.7.7 如您授权第三方向本网站查询、采集您账户相关信息，我们有权在法律法规和您的授权许可范围内向第三方分享您账户的部分信息。</div>
                <div>11.7.8 根据法律法规的规定或有关机关的要求。</div>
                
                <div>
                11.8 本网站在为您提供服务的过程中，不会主动采集、保存涉及侵犯他人隐私的行为，同时您在使用本网站服务的同时应当妥善保存好您及第三人的信息，不擅自向他人提供；因您信息泄露、冒用而产生的任何纠纷均与本网站无关。
                </div>
                <div>
                11.9 为保障信息安全，本网站努力采取各种合理的物理、电子和管理方面的安全措施来保护您的信息，使您的信息不会被泄漏、毁损或者丢失。 
                </div>
                <div>
                11.10 本网站积极采取有效的风险制度要求员工对可能接触到的信息进行严格保密。
                </div>

                <div>
                十二、 不可抗力
                </div>
                <div>
                12.1 因不可抗力或者其他意外事件，使得本协议的履行不可能、不必要或者无意义的，双方均不承担责任。本合同所称之不可抗力指不能预见、不能避免并不能克服的客观情况，包括但不限于战争、台风、水灾、火灾、雷击或地震、罢工、暴动、疾病、黑客攻击、木马、电信部门技术管制、政府行为或任何其它自然或人为造成的灾难等客观情况。 
                </div>
                <div>
                12.2 如任意一方发生不可抗力事件，该方应立即用可能的快捷方式通知另一方，并在 5 个自然日内提供证明文件说明有关事件的细节和原因。双方应在协商一致的基础上决定是否延期履行本协议、终止本协议。
                </div>

                <div>
                十三、 责任范围
                </div>
                <div>
                13.1 本网站仅对本协议中所列明的义务承担责任。
                </div>
                <div>
                13.2 本网站负责按照协议约定及网站描述向您提供服务。您确认知晓本网站对所提供的服务不作任何明示或暗示的保证，包括但不限于服务的适用性、无错误或疏漏、持续性、准确性、可靠性、适用于某一特定用途。同时，本网站也不对服务所涉及的技术及信息的有效性、准确性、正确性、可靠性、质量、稳定、完整和及时性做出任何承诺和保证。   
                </div>
                <div>
                13.3 您明确因交易所产生的任何风险应由交易双方自行承担。   
                </div>
                <div>
                13.4 您应当自行对本网站提供的信息进行识别，本网站无法保证其他您发布信息的真实、及时和完整，您应对您的判断承担全部责任。  
                </div>
                <div>13.5 本网站未对交易标的及本网站服务提供任何形式的保证，包括但不限于以下事项：</div>
                <div>1) 本网站服务将符合您的需求。</div>
                <div>2) 本网站服务将不受干扰、及时提供或免于出錯。</div>
                <div> 13.6 除非法律法规明确要求，或出现以下情况，否则，本网站没有义务对所有您的使用数据、商品（服务）信息、交易行为以及与交易有关的其它事项进行事先审查：</div>
                <div>1) 本网站有合理的理由认为具体交易事项可能存在重大违法或违约情形。</div>
                <div>2) 本网站有合理的理由认为您在本网站的行为涉嫌违法或不当。</div>
                <div>13.7 本网站或本网站授权的第三方或您与本网站一致同意的第三方有权基于您不可撤销的授权受理您与其他您因交易产生的争议，并有权单方判断与该争议相关的事实及应适用的规则，进而做出处理决定，包括但不限于调整相关交易状态。该处理决定对您有约束力。</div>
                <div>
                13.8 您理解并同意，本网站或本网站授权的第三方或您与本网站一致同意的第三方并非司法机构，仅能以普通人的身份对证据进行鉴别，本网站或本网站授权的第三方或您与本网站一致同意的第三方对争议的处理完全是基于您不可撤销的授权，其无法保证争议处理结果符合您的期望，也不对争议处理结论承担任何责任。如您因此遭受损失，您同意自行向受益人索偿。  
                </div>
                <div>
                13.9 您了解并同意，本网站不对因下述任一情况而导致您的任何损害赔偿承担责任，包括但不限于利润、商誉、使用、数据等方面的损失或其它无形损失的损害赔偿 ( 无论本公司是否已被告知该等损害赔偿的可能性 ) ：</div>
                <div>1) 使用本网站服务或者您在本网站服务过程中产生的误解。</div>
                <div>2) 因您账户项下的操作而造成的任何损失或后果等。</div>
                <div>3) 任何非因本网站的原因而引起的其它损失。</div>

                <div>
                十四、 法律争议及适用
                </div>
                <div>
                14.1 本协议的生效、解释、履行及争议的解决均适用中华人民共和国法律（为免歧义，不包括香港、台湾、澳门地区）。
                </div>
                <div>
                14.2 在协议履行期间，凡由本协议引起的或与本协议有关的一切争议、纠纷，您应与本网站首先协商解决。协商不成，向本网站所在地有管辖权的人民法院提起诉讼
                </div>

                <div>
                十五、 其他
                </div>
                <div>
                15.1 本协议为电子版本。  
                </div>
                <div>
                15.2 本协议的某一条款被确认无效，均不影响本协议其他条款的效力。
                </div>
                <div>
                15.3 本协议未尽事宜，由双方另行签订补充协议，补充协议效力与本协议效力相同。 
                </div>
                <div>
                15.4 本协议由本协议条款与本网站公布的其他协议、规则组合而成。如您一旦使用本网站提供的服务，即视为您同时对组成部分的内容均理解并认同，并受本协议所有组成部分的约束。
                </div>
            </div>
            <!-- <div class="">
                <el-button>同意</el-button>
            </div> -->
        </el-dialog>
    </div>
</template>


<script>
    export default {
        data: function(){
            return {
                ruleForm: {
                    username: '',
                    password: '',
                },
                rules: {
                    username: [
                        { required: true, message: '请输入用户名', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' }
                    ]
                },
                agreementAmount:true,
                dialogAgreement:false,
            }
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if(valid){
                        if(this.agreementAmount){
                            this.$axios.defaults.withCredentials=true;
                            this.$axios.get(this.HOSTLogin+'/login',{
                              params:{
                                username:this.ruleForm.username,
                                password:this.ruleForm.password,
                              }
                            })
                            .then(res=>{
                              console.log(res.data);
                              let data=res.data;
                              if(data.status=='101'){
                                sessionStorage.setItem('ms_username',this.ruleForm.username);
                                sessionStorage.setItem('centername',data.shiroUser.name);
                                sessionStorage.setItem('id_p',data.shiroUser.id);
                                // 侧边栏权限数据
                                if(data.shiroUser.menuNodeList!==undefined){
                                    if(data.shiroUser.menuNodeList.length>0){
                                        data.shiroUser.menuNodeList.forEach((item,index,arr)=>{
                                            if(item.id=='168'){
                                                sessionStorage.setItem('sideData',JSON.stringify(item))
                                                //输入框数据
                                                const inputData={
                                                    name:[],
                                                    id:[],
                                                    phone:[],
                                                    bankCard:[]
                                                };
                                                sessionStorage.setItem('inputData',JSON.stringify(inputData))
                                                this.$router.push('/');
                                            }else{
                                                sessionStorage.removeItem('sideData');
                                                this.$router.push('/403')
                                            }
                                        })
                                    }
                                };
                              };
                              if(data==='' || data===null || data==='{}'){
                                this.$message.error('暂无服务');
                              }
                            })
                            .catch(error=>{
                                // alert(error.response.data)
                                
                                // console.log(error.response);
                                if(error.response.data.status=='401'){
                                   this.$message.error('账号密码错误');
                                } else if(error.response.data.status=='404'){
                                   this.$message.error('账号被冻结');
                                }else{
                                   this.$message.error('暂无服务'); 
                                }
                                if(error.response==='' || error.response===null || error.response==='{}'){
                                    this.$message.error('暂无服务');
                                }
                            })
                        }else{
                            this.$message({
                                message:'您还未接受用户协议',
                                type:'warning',
                            })
                        }
                    }
                });
            }
        },
        mounted() {
            // (function() {
            //     var width, height, largeHeader, canvas, ctx, points, target, animateHeader = true;
            //     // Main
            //     initHeader();
            //     initAnimation();
            //     addListeners();

            //     function initHeader() {
            //         width = window.innerWidth;
            //         height = window.innerHeight;
            //         target = {x: width/2, y: height/2};

            //         largeHeader = document.getElementById('login-wrap');
            //         largeHeader.style.height = height+'px';

            //         canvas = document.getElementById('canvas');
            //         canvas.width = width;
            //         canvas.height = height;
            //         ctx = canvas.getContext('2d');

            //         // create points
            //         points = [];
            //         for(var x = 0; x < width; x = x + width/20) {
            //             for(var y = 0; y < height; y = y + height/20) {
            //                 var px = x + Math.random()*width/20;
            //                 var py = y + Math.random()*height/20;
            //                 var p = {x: px, originX: px, y: py, originY: py };
            //                 points.push(p);
            //             }
            //         }

            //         // for each point find the 5 closest points
            //         for(var i = 0; i < points.length; i++) {
            //             var closest = [];
            //             var p1 = points[i];
            //             for(var j = 0; j < points.length; j++) {
            //                 var p2 = points[j]
            //                 if(!(p1 == p2)) {
            //                     var placed = false;
            //                     for(var k = 0; k < 5; k++) {
            //                         if(!placed) {
            //                             if(closest[k] == undefined) {
            //                                 closest[k] = p2;
            //                                 placed = true;
            //                             }
            //                         }
            //                     }

            //                     for(var k = 0; k < 5; k++) {
            //                         if(!placed) {
            //                             if(getDistance(p1, p2) < getDistance(p1, closest[k])) {
            //                                 closest[k] = p2;
            //                                 placed = true;
            //                             }
            //                         }
            //                     }
            //                 }
            //             }
            //             p1.closest = closest;
            //         }

            //         // assign a circle to each point
            //         for(var i in points) {
            //             var c = new Circle(points[i], 2+Math.random()*2, 'rgba(255,255,255,0.3)');
            //             points[i].circle = c;
            //         }
            //     }

            //     // Event handling
            //     function addListeners() {
            //         if(!('ontouchstart' in window)) {
            //             window.addEventListener('mousemove', mouseMove);
            //         }
            //         window.addEventListener('scroll', scrollCheck);
            //         window.addEventListener('resize', resize);
            //     }

            //     function mouseMove(e) {
            //         var posx;
            //         var posy;
            //         var posx = posy = 0;
            //         if (e.pageX || e.pageY) {
            //             posx = e.pageX;
            //             posy = e.pageY;
            //         }
            //         else if (e.clientX || e.clientY)    {
            //             posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            //             posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
            //         }
            //         target.x = posx;
            //         target.y = posy;
            //     }

            //     function scrollCheck() {
            //         if(document.body.scrollTop > height) animateHeader = false;
            //         else animateHeader = true;
            //     }

            //     function resize() {
            //         width = window.innerWidth;
            //         height = window.innerHeight;
            //         largeHeader.style.height = height+'px';
            //         canvas.width = width;
            //         canvas.height = height;
            //     }

            //     // animation
            //     function initAnimation() {
            //         animate();
            //         for(var i in points) {
            //             shiftPoint(points[i]);
            //         }
            //     }

            //     function animate() {
            //         if(animateHeader) {
            //             ctx.clearRect(0,0,width,height);
            //             for(var i in points) {
            //                 // detect points in range
            //                 if(Math.abs(getDistance(target, points[i])) < 4000) {
            //                     points[i].active = 0.3;
            //                     points[i].circle.active = 0.6;
            //                 } else if(Math.abs(getDistance(target, points[i])) < 20000) {
            //                     points[i].active = 0.1;
            //                     points[i].circle.active = 0.3;
            //                 } else if(Math.abs(getDistance(target, points[i])) < 40000) {
            //                     points[i].active = 0.02;
            //                     points[i].circle.active = 0.1;
            //                 } else {
            //                     points[i].active = 0;
            //                     points[i].circle.active = 0;
            //                 }

            //                 drawLines(points[i]);
            //                 points[i].circle.draw();
            //             }
            //         }
            //         requestAnimationFrame(animate);
            //     }

            //     function shiftPoint(p) {
            //         TweenLite.to(p, 1+1*Math.random(), {x:p.originX-50+Math.random()*100,
            //             y: p.originY-50+Math.random()*100, ease:Circ.easeInOut,
            //             onComplete: function() {
            //                 shiftPoint(p);
            //             }});
            //     }

            //     // Canvas manipulation
            //     function drawLines(p) {
            //         if(!p.active) return;
            //         for(var i in p.closest) {
            //             ctx.beginPath();
            //             ctx.moveTo(p.x, p.y);
            //             ctx.lineTo(p.closest[i].x, p.closest[i].y);
            //             ctx.strokeStyle = 'rgba(156,217,249,'+ p.active+')';
            //             ctx.stroke();
            //         }
            //     }

            //     function Circle(pos,rad,color) {
            //         var _this = this;

            //         // constructor
            //         (function() {
            //             _this.pos = pos || null;
            //             _this.radius = rad || null;
            //             _this.color = color || null;
            //         })();

            //         this.draw = function() {
            //             if(!_this.active) return;
            //             ctx.beginPath();
            //             ctx.arc(_this.pos.x, _this.pos.y, _this.radius, 0, 2 * Math.PI, false);
            //             ctx.fillStyle = 'rgba(156,217,249,'+ _this.active+')';
            //             ctx.fill();
            //         };
            //     }

            //     // Util
            //     function getDistance(p1, p2) {
            //         return Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2);
            //     }
                
            // })();
        },
        // created(){
        
        // }
    }
</script>

<style scoped>
    .login-wrap{
        position: relative;
        width:100%;
        height:100%;
        min-width: 1000px;
        /*overflow: hidden;*/
        background-size: cover;
        background-position: center center;
        z-index: 1;
        background-image: url(../../assets/img/bg.jpeg);
    }
    .el-checkbox{
        color: #fff;
    }
    .agrermentContent{
        width: 100%;
        max-height: 500px;
        overflow-y: scroll;
    }
    .agrermentContent div{
        min-height: 30px;
        line-height: 30px;
    }
    .ba-content{
        width: 45%;
        height: 45%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
        background: rgba(0,0,0,0.5);
        display: flex;
        flex-direction:row; 
        border-radius: 5px;
    }
    .ms-title{
        flex: 2;
        display: flex;
        display: -webkit-flex;
        justify-content: center;
        align-items: center;
    }
    .ms-cont{
        width: 60%;
        height: 30%;
    }
    .ms-cont1{ 
        height: 60%;
        background-image: url(../../assets/img/logo.png);
        background-repeat: no-repeat;
        background-position:center center; 
        background-size: contain;
    }
    .ms-cont2{
        height: 40%;
        text-align: center;
        color: #fff;
        font-weight: 40;
        letter-spacing:0.1rem;
        font-size: 1.3rem;
    }
    .ms-login{
        flex: 3;
        display: flex;
        display: -webkit-flex;
        align-items: center;
    }
    .ms-loginContent{
        min-height: 40%;
        width: 80%;
    }
    .loginContent1{
        height: 40px;
        line-height: 40px;
        color: #fff;
    }
    .el-input--small{
        background: #fff;
    }
    .el-form-item{
        height: 40px;
        /*border-radius: 5px;*/
    }
    .login-msg {
        /*border-radius: 5px;*/
    }
    .login-btn{
        text-align: center;
    }
    .login-btn button{
        width: 100%;
        height: 40px;
        color: #fff;
        font-size: 1.2em; 
        letter-spacing: 0.5em;
        border: 0;
    }
    .agreement{
        height: 30px;
        line-height: 30px;
    }
    @media screen and (max-width: 1400px) {
        .login-wrap{
            position: relative;
            /*width:1366px;*/
            /*min-width: 1000px;*/
            overflow: hidden;
            background-size: contain;
        }
        
       
        
    }
    @media screen and (max-width: 1500px){
        .login-wrap{
            position: relative;
            /*width:1440px;*/
            min-width: 1000px;
            overflow: hidden;
            background-size: cover;
        }
        
    }
</style>